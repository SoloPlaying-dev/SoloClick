document.addEventListener('DOMContentLoaded', function() {
    console.log("script.js: DOMContentLoaded - El script se está ejecutando.");

    // Implementación del modal personalizado (en lugar de alert)
    function showCustomModal(message) {
        let modal = document.getElementById('customModal');
        let backdrop = document.getElementById('modalBackdrop');

        // Verifica si el modal y el fondo existen, si no, créalos
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'customModal';
            document.body.appendChild(modal); // Añadir al body primero para aplicar estilos

            let modalContent = document.createElement('p');
            modalContent.id = 'customModalContent';
            modalContent.style.marginBottom = '20px';
            modal.appendChild(modalContent);

            let closeButton = document.createElement('button');
            closeButton.textContent = 'Cerrar';
            closeButton.onclick = function() {
                modal.style.display = 'none';
                if (backdrop) {
                    backdrop.style.display = 'none';
                }
            };
            modal.appendChild(closeButton);
        }

        if (!backdrop) {
            backdrop = document.createElement('div');
            backdrop.id = 'modalBackdrop';
            document.body.appendChild(backdrop); // Añadir al body primero para aplicar estilos
        }
        
        // Aplica estilos (principalmente desde CSS, pero asegura que el display esté configurado)
        modal.style.display = 'block';
        backdrop.style.display = 'block';

        document.getElementById('customModalContent').textContent = message;
    }

    // Función para mostrar solo una sección y ocultar las demás
    window.showSection = function(sectionId) {
        console.log("showSection: Intentando mostrar la sección:", sectionId);
        const sections = document.querySelectorAll('main section');
        let foundSection = false;
        sections.forEach(section => {
            if (section.id === sectionId) {
                section.classList.add('active'); // Muestra la sección deseada
                foundSection = true;
                console.log("showSection: Sección encontrada y activada:", sectionId);
            } else {
                section.classList.remove('active'); // Oculta las demás secciones
            }
        });

        // Si la sección no se encuentra (ej. por un enlace roto), mostrar la primera
        if (!foundSection && sections.length > 0) {
            sections[0].classList.add('active');
            console.log("showSection: Sección no encontrada, mostrando la primera sección por defecto.");
        } else if (sections.length === 0) {
            console.log("showSection: No se encontraron secciones en el documento.");
        }
    };

    // Lógica para el botón de búsqueda
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');

    if (searchButton && searchInput) {
        searchButton.addEventListener('click', function() {
            const query = searchInput.value.toLowerCase().trim();
            if (query) {
                const sections = document.querySelectorAll('main section');
                let foundMatch = false;
                for (let i = 0; i < sections.length; i++) {
                    const section = sections[i];
                    const sectionText = section.textContent.toLowerCase();
                    const sectionId = section.id.toLowerCase();

                    // Buscar en el ID o en el contenido de la sección. Se añadió reemplazo de espacio para la búsqueda.
                    if (sectionId.includes(query) || sectionId.includes(query.replace(/-/g, ' ')) || sectionText.includes(query)) { 
                        showSection(section.id);
                        foundMatch = true;
                        break; // Mostrar la primera coincidencia y salir
                    }
                }

                if (!foundMatch) {
                    showCustomModal('No se encontró ninguna sección que coincida con su búsqueda.');
                    showSection('historia'); // Volver a la sección inicial si no hay coincidencias
                }
            } else {
                showCustomModal('Por favor, ingrese un término de búsqueda.');
                showSection('historia'); // Volver a la sección inicial si la búsqueda está vacía
            }
        });

        // Opcional: Permitir buscar al presionar Enter en el campo de búsqueda
        searchInput.addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                searchButton.click();
            }
        });
    }

    // Lógica para los botones de copiar
    const copyButtons = document.querySelectorAll('.copy-button');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const textToCopy = this.dataset.text; // Obtiene el texto del atributo data-text
            const tempInput = document.createElement('textarea'); // Usa textarea para copiar múltiples líneas si es necesario
            tempInput.value = textToCopy;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy'); // Copia el texto al portapapeles
            document.body.removeChild(tempInput);
            showCustomModal('¡Copiado al portapapeles: ' + textToCopy + '!');
        });
    });

    // Lógica para los botones de compra
    const buyButtons = document.querySelectorAll('.buy-button');
    buyButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Abre la nueva página de oferta en una nueva pestaña
            window.open('oferta.html', '_blank');
        });
    });

    // Lógica para el formulario de contacto
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Evita el envío real del formulario

            const fullName = document.getElementById('fullName').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            // Aquí normalmente enviarías los datos a un servidor (e.g., usando fetch API)
            // Para este ejemplo, solo mostraremos un mensaje de confirmación
            showCustomModal(`¡Gracias, ${fullName}! Tu mensaje ha sido enviado. Te contactaremos pronto a ${email}.`);

            // Opcional: Limpiar el formulario después del envío
            contactForm.reset();
        });
    }

    // Lógica para el botón "Volver Arriba" y el botón flotante de compra
    const backToTopBtn = document.getElementById('backToTopBtn');
    const floatingBuyBtn = document.getElementById('floatingBuyBtn');

    // Mostrar/ocultar los botones al hacer scroll
    window.addEventListener('scroll', function() {
        if (window.scrollY > 200) { // Mostrar los botones después de 200px de scroll
            backToTopBtn.style.display = 'block';
            floatingBuyBtn.style.display = 'block';
        } else {
            backToTopBtn.style.display = 'none';
            floatingBuyBtn.style.display = 'none';
        }
    });

    // Hacer scroll suave al hacer clic en el botón "Volver Arriba"
    if (backToTopBtn) {
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Mostrar la sección "Historia" al cargar la página por primera vez
    showSection('historia');
});

